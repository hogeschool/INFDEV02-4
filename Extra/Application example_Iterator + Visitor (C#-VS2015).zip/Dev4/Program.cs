﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CustomersRepository;
using Utils;
namespace Dev4
{
  class Program
  {
    static void Main(string[] args)
    {
      Repository repository = new Repository();
      
      Customer andrew = new Customer("9", Gender.Male);
      Customer timo = new Customer("1", Gender.Male);
      Customer chava = new Customer("5", Gender.Female);
      
      repository.Add(andrew);
      repository.Add(timo);
      repository.Add(chava);

      IterateAndDoSomething(repository, 
                            value => Console.WriteLine("My id and gender are {0} and {1}", value.Id, value.Gender));


      Console.WriteLine("\n\n\n");
      repository.Update(chava, new Customer("0", chava.Gender));

      IterateAndDoSomething(repository,
                            value => Console.WriteLine("My id and gender are {0} and {1}", value.Id, value.Gender));
      Console.WriteLine("\n\n\n");

      repository.Remove(timo);
      IterateAndDoSomething(repository,
                            value => Console.WriteLine("My id and gender are {0} and {1}", value.Id, value.Gender));

      Console.WriteLine(repository.GetCustomer("0").Visit(value => "Found it! It's a " + value.Gender, 
                                                          () => "Not found :("));
    }

    static void IterateAndDoSomething<T>(Iterator<T> collection, Action<T> action)
    {
      collection.Reset();
      Option<T> current_option = collection.GetNext();
      
      while (current_option.Visit(value => true, () => false))
      {
        action(current_option.Visit(value => value, () => default(T)));
        current_option = collection.GetNext();
      }

    }
  }
}
