﻿using Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomersRepository
{

  public enum Gender { Male, Female }

  public interface ICustomer
  {
    string Id { get; }
    Gender Gender { get; }
  }
  public class Customer : ICustomer
  {
    string id;
    public string Id { get { return id; } internal set { id = value; } }

    Gender gender;
    public Gender Gender { get { return gender; } internal set { gender = value; } }

    public Customer(string id, Gender gender)
    {
      this.id = id;
      this.gender = gender;
    }
  }

  public interface IRepository {
    void Add(ICustomer c);
    void Remove(ICustomer c);
    void Update(ICustomer _old, ICustomer _new);
    Option<ICustomer> GetCustomer(string id);
  }

  

  public class Repository : IRepository, Iterator<ICustomer>
  {
    List<Customer> customers;
    readonly int default_index = -1;
    int index;
    public Repository()
    {
      customers = new List<Customer>();
      index = default_index;
    }

    public void Reset()
    {
      index = default_index;
    }
    public Option<ICustomer> GetNext()
    {
      index = index + 1;
      if(index < customers.Count)
      {
        return new Some<ICustomer>(customers[index]);
      }
      return new None<ICustomer>();
    }

    public void Add(ICustomer c)
    {
      customers.Add(new Customer(c.Id, c.Gender));
    }

    public void Remove(ICustomer c)
    {
      //customers.RemoveAll(_c => c.Gender == _c.Gender && c.Id == _c.Id);
      List<Customer> new_customers = new List<Customer>();
      foreach (ICustomer customer in customers)
      {
        if (customer.Gender != c.Gender || customer.Id != c.Id)
        {
          new_customers.Add(new Customer(customer.Id, customer.Gender));
        }
      }
      customers = new_customers;
    }

    public void Update(ICustomer _old, ICustomer _new)
    {
      foreach (Customer customer in customers)
      {
        if (customer.Gender == _old.Gender && customer.Id == _old.Id)
        {
          customer.Gender = _new.Gender;
          customer.Id = _new.Id;
        }
      }
    }

    public Option<ICustomer> GetCustomer(string id)
    {
      foreach (ICustomer customer in customers)
      {
        if(id == customer.Id)
        {
          return new Some<ICustomer>(customer);
        }
      }
      return new None<ICustomer>();
    }



    //add
    //remove
    //update
  }

}
