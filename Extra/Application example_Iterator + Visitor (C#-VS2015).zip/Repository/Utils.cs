﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Utils
{
  public interface Option<T> {
    U Visit<U>(Func<T, U> onSome, Func<U> onNone);
  }
  public class Some<T> : Option<T>
  {
    T value;
    public Some(T value) { this.value = value; }

    public U Visit<U>(Func<T, U> onSome, Func<U> onNone)
    {
      return onSome(value);
    }
  }
  public class None<T> : Option<T>
  {
    public U Visit<U>(Func<T, U> onSome, Func<U> onNone)
    {
      return onNone();
    }
  }
  public interface Iterator<T>
  {
    Option<T> GetNext();
    void Reset();
  }
}
